package com.example.internship;

import java.util.List;

public class directory {

	private final List<people> peoples;
		
	directory(List<people> peoples){
		this.peoples = peoples;
	}
	
	public List<people> printDirectory() {
		return peoples;
	}


}
