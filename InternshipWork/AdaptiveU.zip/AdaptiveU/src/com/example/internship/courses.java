package com.example.internship;


public class courses {
	
	private String courseName;
	private int duration;
		
	public courses(String string, int i) {
		courseName = string;
		duration = i;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getDuration() {
		return duration;
	}

}
