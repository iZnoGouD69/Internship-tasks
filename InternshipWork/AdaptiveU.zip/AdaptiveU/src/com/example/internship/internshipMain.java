package com.example.internship;

import java.util.ArrayList;
//import java.util.Collections;
import java.util.List;

public class internshipMain {
	
	public static void main(String[] args) {
		people user_1 = new people("Parth","Gujarat",0);
		people user_2 = new people("Alok","Delhi",0);
		people user_3 = new people("Mitul","Bangalore",0);
		people user_4 = new people("Darshan","Pune",0);
		
		
		courses basic = new courses("Oops Concepts",50);
		courses frontend = new courses("ReactJS",300);
		courses backend = new courses("Node",100);
		courses cloud = new courses("AWS",200);
		
		
		List<people> peoples = new ArrayList<people>();
		peoples.add(user_1);
		peoples.add(user_2);
		peoples.add(user_3);
		peoples.add(user_4);
		
	
		user_1.takeCourse(basic);
		user_2.takeCourse(frontend);
		user_3.takeCourse(backend);
		user_4.takeCourse(cloud);
		
		
		
		// To print leaderboard which is sorted by duration
		leaderboard display = new leaderboard(peoples);
		peoples = display.GetLeaderboard();

		
		
		// To print directory which is not sorted
		//directory all = new directory(peoples);
		//peoples = all.printDirectory();
		
		
		for(people pp : peoples) {
			System.out.println("Employee Name: " + pp.name + "\n" +
			"Employee Location: " + pp.location + "\n" +
			"Duration Watched: " + pp.duration);
			System.out.println("=================================");
		}
	}
}