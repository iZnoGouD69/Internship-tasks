package com.example.internship;

import java.util.Collections;
import java.util.List;

public class leaderboard {
	
	private final List<people> peoples;
	
	leaderboard(List<people> peoples){
		this.peoples = peoples;
	}
	
	public List<people> GetLeaderboard(){
		//Collections.sort(peoples,Collections.reverseOrder());
		//Collections.sort(peoples);
		Collections.sort(peoples,(people o1, people o2) -> 
			o2.duration - o1.duration
		);
		return peoples;
	}
}
