package com.example.internship;

public class people  /*implements Comparable<people>*/ {
	
	String name;
	String location;
	int duration;
	
	
	people(String name,String location,int duration){
		
		this.name = name;
		this.location = location;
		this.duration = duration;
		 
	}
	

	public void takeCourse(courses takenCourse) {
		//return takenCourse.getDuration();
		this.duration =+ takenCourse.getDuration();
		
	}
	
	/*@Override
	public int compareTo(people durationWatched) {
		// TODO Auto-generated method stub
		
		int compareDuration = ((people)durationWatched).getDuration();
		
		return this.duration - compareDuration;
	}*/

}
