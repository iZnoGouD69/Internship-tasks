package com.example.internship;

import java.util.Comparator;

public class sortByDuration implements Comparator<people>{

	@Override
	public int compare(people o1, people o2) {
		// TODO Auto-generated method stub
		return o2.duration - o1.duration;
	}

}
