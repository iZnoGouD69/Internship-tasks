module AdaptiveU {
}